package org.example.server;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/trees")
public class TreeController {
	private final TreeService treeService;

	@Autowired
	public TreeController(TreeService treeService) {
		this.treeService = treeService;
	}

	@GetMapping
	public ResponseEntity<List<TreeEntity>> getAllTrees() {
		return ResponseEntity.ok(treeService.getAllTrees());
	}

	@GetMapping("/{rootId}")
	public ResponseEntity<TreeEntity> getTreeStructure(@PathVariable int rootId) {
		TreeEntity treeStructure = treeService.getTreeStructure(rootId);
		if (treeStructure == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(treeStructure);
	}

	@PostMapping
	public ResponseEntity<Void> addTree(@RequestBody TreeEntity root) {
		treeService.addTree(root);
		return ResponseEntity.ok().build();
	}

	@DeleteMapping("/{nodeId}")
	public ResponseEntity<Void> deleteNode(@PathVariable int nodeId) {
		treeService.deleteNode(nodeId);
		return ResponseEntity.ok().build();
	}

	@PostMapping("/{parentId}/addChild")
	public ResponseEntity<Void> addChildNode(@PathVariable int parentId, @RequestBody int childId) {
		treeService.addChildNode(parentId, childId);
		return ResponseEntity.ok().build();
	}
}


@Entity
@Table(name = "TREES")
public class TreeEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long primaryId;

	@Column(name = "id")
	private Integer id;

	@Column(name = "parent_id")
	private Integer parentId;

	// Геттеры и сеттеры
}


@Repository
public interface TreeRepository extends JpaRepository<TreeEntity, Long> {
}

@Service
public class TreeService {
	private final TreeRepository treeRepository;
	private final TreeNodeRepository treeNodeRepository;

	@Autowired
	public TreeService(TreeRepository treeRepository, TreeNodeRepository treeNodeRepository) {
		this.treeRepository = treeRepository;
		this.treeNodeRepository = treeNodeRepository;
	}

	public List<TreeEntity> getAllTrees() {
		return treeRepository.findAll();
	}

	public TreeEntity getTreeStructure(Integer rootId) {
		// Преобразуйте TreeEntity в TreeStructure здесь, если необходимо
		return treeRepository.findById(Long.valueOf(rootId)).orElse(null);
	}

	public void deleteNode(Integer nodeId) {
		treeNodeRepository.deleteById(Long.valueOf(nodeId));
	}

	public void addChildNode(Integer parentId, Integer childId) {
		TreeNodeEntity childNode = new TreeNodeEntity();
		childNode.setId(Long.valueOf(childId));
		childNode.setParentId(Long.valueOf(parentId));
		treeNodeRepository.save(childNode);
	}

	public void addTree(TreeEntity treeEntity) {
		treeRepository.save(treeEntity);
	}

	public List<Integer> getRootNodeIds() {
		// Для получения корневых узлов, вам возможно понадобится создать запрос в репозитории
		// Этот метод может потребовать дополнительной логики в зависимости от структуры ваших сущностей
		return treeNodeRepository.findRootNodeIds();
	}

	// Дополнительные методы, если нужно воссоздать логику TreeBuilder и другие функции
}
class TreeBuilder {
	public static List<Tree> buildTreesFromDB(DBConnection dbConnection) throws SQLException {
		List<Tree> trees = new ArrayList<>();
		Tree currentTree = null;

		try (Connection conn = dbConnection.getConnection();
			 Statement stmt = conn.createStatement();
			 ResultSet rs = stmt.executeQuery("SELECT * FROM TREES")) {

			while (rs.next()) {
				int nodeId = rs.getInt("id");
				int parentId = rs.getInt("parent_id");

				if (nodeId == parentId) {
					// Если узел является корнем, начинаем новое дерево
					currentTree = new Tree(new TreeNode(nodeId));
					trees.add(currentTree);
				} else if (currentTree != null) {
					// Добавляем узел в текущее дерево
					TreeNode parentNode = findNode(currentTree.getRoot(), parentId);
					if (parentNode != null) {
						parentNode.addChild(new TreeNode(nodeId));
					}
				}
			}
		}

		return trees;
	}

	private static TreeNode findNode(TreeNode current, int id) {
		if (current == null) {
			return null;
		}
		if (current.getID() == id) {
			return current;
		}
		for (TreeNode child : current.getChildNodes()) {
			TreeNode result = findNode(child, id);
			if (result != null) {
				return result;
			}
		}
		return null;
	}
	public static int getTotalLeaves(List<Tree> trees) {
		int totalLeaves = 0;
		for (Tree tree : trees) {
			totalLeaves += tree.getLeaves().size();
		}
		return totalLeaves;
	}
}
class TreeStructure {
	private TreeNode root;

	public TreeStructure(Tree tree) {
		this.root = tree.getRoot();
	}

	public int getRootId() {
		return root.getID();
	}

	public List<Integer> getChildrenIds() {
		List<Integer> childrenIds = new ArrayList<>();
		for (TreeNode child : root.getChildNodes()) {
			childrenIds.add(child.getID());
		}
		return childrenIds;
	}

	public List<TreeNode> getNonRootNodes() {
		List<TreeNode> nonRootNodes = new ArrayList<>();
		addNonRootNodes(root, nonRootNodes);
		return nonRootNodes;
	}

	private void addNonRootNodes(TreeNode node, List<TreeNode> nonRootNodes) {
		if (node == null) {
			return;
		}
		if (!node.isRoot()) {
			nonRootNodes.add(node);
		}
		for (TreeNode child : node.getChildNodes()) {
			addNonRootNodes(child, nonRootNodes);
		}
	}
}
class TreeNode {
	private int id; // id узла
	private List<TreeNode> childNodes; // список дочерних узлов (т.е. ссылок на дочерние узлы)
	private TreeNode parentNode; // родительский узел

	public TreeNode(int id) {
		// конструктор класса TreeNode
		this.id = id;
		this.childNodes = new ArrayList<>();
	}

	public int getID() {
		// Получить id
		return id;
	}

	public TreeNode getParent() {
		// Получить родительский узел
		return parentNode;
	}

	public List<TreeNode> getChildNodes() {
		// Получить список всех нижележащих (дочерних) узлов, соединенных с ним
		// переходом
		return childNodes;
	}

	public boolean isLeaf() {
		// Является ли узел листом (т.е. узлом, у которого нет дочерних узлов)
		return childNodes.isEmpty();
	}

	public boolean isRoot() {
		// Является ли узел корнем (т.е. узлом, у которого нет родительских узлов)
		return parentNode == null;
	}

	public void addChild(TreeNode childNode) {
		childNodes.add(childNode);
		childNode.parentNode = this;

	}
}
class Tree {
	private TreeNode root; // корень дерева

	public Tree(TreeNode root) {
		// конструктор класса
		this.root = root;
	}

	public TreeNode getRoot() {
		// получить корень
		return root;
	}

	public void insertNode(int id, int parentId) {
		// вставить узел
		if (root == null) {
			root = new TreeNode(parentId);
		}

		TreeNode parentNode = findNode(root, parentId);
		if (parentNode != null) {
			parentNode.addChild(new TreeNode(id));
		}
	}

	private TreeNode findNode(TreeNode current, int id) {
		if (current == null) {
			return null;
		}
		if (current.getID() == id) {
			return current;
		}
		for (TreeNode child : current.getChildNodes()) {
			TreeNode result = findNode(child, id);
			if (result != null) {
				return result;
			}
		}
		return null;
	}

	public List<TreeNode> getNodes() {
		// получить список всех узлов
		List<TreeNode> nodes = new ArrayList<>();
		getNodesRecursive(root, nodes);
		return nodes;
	}

	private void getNodesRecursive(TreeNode current, List<TreeNode> nodes) {
		// рекурсивная функция для обхода всех узлов дерева
		nodes.add(current);
		for (TreeNode child : current.getChildNodes()) {
			getNodesRecursive(child, nodes);
		}
	}

	public List<TreeNode> getLeaves() {
		// получить список всех листов дерева
		List<TreeNode> leaves = new ArrayList<>();
		getLeavesRecursive(root, leaves);
		return leaves;
	}

	private void getLeavesRecursive(TreeNode current, List<TreeNode> leaves) {
		if (current.isLeaf()) {
			leaves.add(current);
		}
		for (TreeNode child : current.getChildNodes()) {
			getLeavesRecursive(child, leaves);
		}
	}
}
